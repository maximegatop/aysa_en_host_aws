    var table_tps = $('#table_tps').DataTable( {
       "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
        },
        autoWidth: true,
        
        pageLength: 6,
        scrollY: 270,
        lengthChange: false,
        select: 'single',
        preDrawCallback: function (settings) {
            var api = new $.fn.dataTable.Api(settings);
            var pagination = $(this)
            .closest('.dataTables_wrapper')
            .find('.dataTables_paginate');

            if (api.page.info().pages <= 1) {
                pagination.hide();
            }
            else {
                pagination.show();
            }

            }
    });
