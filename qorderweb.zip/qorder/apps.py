from django.apps import AppConfig


class QorderConfig(AppConfig):
    name = 'qorder'
